﻿--------------------------------------------------------------------------------------------------
February 25, 2005
--------------------------------------------------------------------------------------------------
Author			:           papakarlo787 (Evgeniy Perezhogin)
Contact Info	:           evgeniy8a8p@gmail.com
Version			:           2.0
Date of Release	:           November 25, 2021
--------------------------------------------------------------------------------------------------
Briefing:
My friend Basso gave me information that the hobbit Bilbo Baggins lives in a hole under the Hill.
Rumor has it that he has a huge pile of all sorts of good, which he brought with him after he disappeared
for a year with a magician and dwarves. I also heard rumors that he keeps a very expensive and cute little
thing that I could attach to the right place... Now he is away visiting his friend Elrond the elf.
The house is carefully guarded, I must not get seen, otherwise I will be caught not now then later!
--------------------------------------------------------------------------------------------------
*Playing Information*
Game					:           Thief 3 - Deadly Shadows
Mission Title			:           The Hobbit
Mission File Name		:           Hobbit
Difficulty Settings		:           No
Equipment Store			:           No
Map						:           No
Auto Map				:           No
New Graphics			:           No
New Sounds				:           Yes
New Objects				:           No
Multi language support  :           No
Difficulty Level Info	:           Easy, Normal, Hard, Expert
Known Bugs				:           None
--------------------------------------------------------------------------------------------------
Video Briefing Length	: N/A
Video Briefing Size		: N/A
--------------------------------------------------------------------------------------------------
*Construction*
Base			:           From Scratch
Build Time		:           3 weeks
--------------------------------------------------------------------------------------------------
Notes :
This is my first fan mission ever :-)
-------------------------------------------------------------------------------------------------
Thanks :
Voice actor - Ivan Sibirtsev
Everyone from forums darkfate.org and others, especially Chuzhoi, Savar, Glypher and Komag of course!
--------------------------------------------------------------------------------------------------
*Loading Information*
Runs from GarrettLoader.  Leave the file ZIPPED - DO NOT UNZIP this file, but put the whole zip file
into whatever folder/directory on your hard drive where you keep your Thief 3 FMs, then run GarrettLoader and play!
--------------------------------------------------------------------------------------------------
* Copyright Information *
This level is © by Evgeniy Perezhogin (papakarlo787)
Distribution of this level is allowed in any way, shape, or manner you wish.  You may edit or use
this mission however you want.  It's all yours!
--------------------------------------------------------------------------------------------------
